import React from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import PantryApp from "./PantryApp.jsx";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <PantryApp />
  </React.StrictMode>
);
