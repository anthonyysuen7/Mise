# Pantry Recipe Scanner

Complete Vite + React wrapper around the uploaded `PantryApp.jsx` and Vercel API functions.

## Run locally

```bash
npm install
cp .env.example .env.local
# edit .env.local and add your ANTHROPIC_API_KEY
npm run dev
```

Open the local Vite URL shown in the terminal.

## Deploy on Vercel

1. Push this folder to GitHub or upload/import it into Vercel.
2. In Vercel, add the environment variable:

```txt
ANTHROPIC_API_KEY=your_anthropic_key_here
```

3. Deploy.

The frontend calls:

```txt
/api/scan
/api/recipes
```

Those API functions keep the Anthropic key server-side so it is not exposed in the browser.
