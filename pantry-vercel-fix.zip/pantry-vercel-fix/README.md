# Pantry app Vercel fix

## What changed

- `PantryApp.jsx` no longer calls `https://api.anthropic.com/v1/messages` directly from the browser.
- Photo scanning now calls `/api/scan`.
- Web recipe search now calls `/api/recipes`.
- The API key stays server-side in Vercel environment variables.
- Uploaded photos are compressed in the browser before sending to the serverless function.

## Files to copy into your project

Copy these into your app:

```txt
PantryApp.jsx
api/scan.js
api/recipes.js
```

For a regular React/Vite app deployed on Vercel, the `api` folder should sit at the project root:

```txt
your-project/
  api/
    scan.js
    recipes.js
  src/
    PantryApp.jsx
```

If your component lives in `src/components`, put `PantryApp.jsx` there instead. The important part is that `/api/scan` and `/api/recipes` are available at the root route.

## Vercel environment variable

In Vercel, go to:

`Project Settings → Environment Variables`

Add:

```txt
ANTHROPIC_API_KEY=your_anthropic_key_here
```

Optional:

```txt
ANTHROPIC_MODEL=claude-sonnet-4-6
```

Then redeploy.

## Local testing

If you use Vercel CLI:

```bash
vercel dev
```

Add a local `.env` or `.env.local` with:

```txt
ANTHROPIC_API_KEY=your_anthropic_key_here
```

Do not commit your `.env` file.
