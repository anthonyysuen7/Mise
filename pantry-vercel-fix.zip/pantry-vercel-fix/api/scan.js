const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";

async function parseJsonBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") return JSON.parse(req.body || "{}");

  return await new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on("error", reject);
  });
}

function extractJsonArray(text) {
  const cleaned = String(text || "").replace(/```json|```/g, "").trim();
  const match = cleaned.match(/\[[\s\S]*\]/);
  if (!match) throw new Error("Could not find a JSON array in Claude's response.");
  return JSON.parse(match[0]);
}

function normalizeIngredientItems(items) {
  return items
    .filter((item) => item && typeof item.name === "string" && item.name.trim())
    .map((item) => ({
      name: item.name.trim(),
      category: typeof item.category === "string" && item.category.trim() ? item.category.trim() : "Other",
      confidence: typeof item.confidence === "number" ? Math.max(0, Math.min(1, item.confidence)) : 0.7,
    }));
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: "Missing ANTHROPIC_API_KEY environment variable in Vercel." });
  }

  try {
    const { base64Data, mediaType = "image/jpeg" } = await parseJsonBody(req);

    if (!base64Data || typeof base64Data !== "string") {
      return res.status(400).json({ error: "Missing image data." });
    }

    const anthropicResponse = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: mediaType, data: base64Data } },
              {
                type: "text",
                text: `Identify every distinct food ingredient visible in this photo (fridge, pantry, or counter). For each one, give a clean, singular display name as it would appear on a recipe ingredient list (e.g. "Bell Pepper" not "red peppers" or "red pepper sitting on shelf"; "Tomato" not "Tomatoes"), a category from this exact list: Produce, Protein, Dairy, Grains, Pantry, Spices, Other — and a confidence from 0 to 1.

Respond with ONLY valid JSON, no markdown fences, no preamble, no explanation. Format:
[{"name": "Garlic", "category": "Produce", "confidence": 0.95}]

If nothing identifiable is visible, return an empty array: []`,
              },
            ],
          },
        ],
      }),
    });

    const data = await anthropicResponse.json().catch(() => ({}));

    if (!anthropicResponse.ok) {
      return res.status(anthropicResponse.status).json({
        error: data?.error?.message || `Anthropic request failed (${anthropicResponse.status}).`,
      });
    }

    const text = (data.content || [])
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("\n");

    const items = normalizeIngredientItems(extractJsonArray(text));
    return res.status(200).json({ items });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Something went wrong scanning the image." });
  }
};
