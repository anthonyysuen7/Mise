const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";

async function parseJsonBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") return JSON.parse(req.body || "{}");

  return await new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on("error", reject);
  });
}

function extractJsonArray(text) {
  const cleaned = String(text || "").replace(/```json|```/g, "").trim();
  const match = cleaned.match(/\[[\s\S]*\]/);
  if (!match) throw new Error("Could not parse recipe results from Claude's response.");
  return JSON.parse(match[0]);
}

function normalizeRecipes(recipes) {
  return recipes
    .filter((recipe) => recipe && typeof recipe.name === "string" && recipe.name.trim())
    .slice(0, 8)
    .map((recipe) => ({
      name: recipe.name.trim(),
      blurb: recipe.blurb || "",
      time: Number(recipe.time) || 30,
      servings: Number(recipe.servings) || 4,
      difficulty: ["Easy", "Medium", "Hard"].includes(recipe.difficulty) ? recipe.difficulty : "Medium",
      cuisine: recipe.cuisine || "",
      need: Array.isArray(recipe.need) ? recipe.need.filter(Boolean).map(String) : [],
      steps: Array.isArray(recipe.steps)
        ? recipe.steps.map((step) => ({
            t: step?.t || "Step",
            d: step?.d || "",
            time: Number(step?.time) || undefined,
          }))
        : [],
      tips: recipe.tips || "",
      swaps: recipe.swaps || "",
      source: recipe.source && typeof recipe.source === "object" ? recipe.source : null,
    }));
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: "Missing ANTHROPIC_API_KEY environment variable in Vercel." });
  }

  try {
    const { ingredients } = await parseJsonBody(req);
    const pantryList = Array.isArray(ingredients) ? ingredients.map(String).filter(Boolean) : [];

    if (pantryList.length === 0) {
      return res.status(400).json({ error: "Add a few ingredients first." });
    }

    const anthropicResponse = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6",
        max_tokens: 4000,
        messages: [
          {
            role: "user",
            content: `Search the web for 5-6 real, well-reviewed recipes that make good use of as many of these on-hand ingredients as possible: ${pantryList.join(", ")}.

Favor recipes that use several of these ingredients together over recipes that only use one. Include a mix of difficulty levels. Use real recipes from real sites, and keep each recipe's ingredients and method faithful to the actual source. Rewrite steps in your own words rather than copying text verbatim.

After researching, respond with ONLY a JSON array, no markdown fences, no preamble, no text before or after. Each recipe must follow this exact schema:
[{
  "name": "Recipe Name",
  "blurb": "One sentence, appetizing description",
  "time": 30,
  "servings": 4,
  "difficulty": "Easy",
  "cuisine": "Italian",
  "need": ["Ingredient One", "Ingredient Two"],
  "steps": [{"t": "Short step title", "d": "Full instruction in your own words, wrap ingredient mentions in curly braces like {Ingredient One}", "time": 5}],
  "tips": "One practical cook's tip",
  "swaps": "One substitution suggestion",
  "source": {"name": "Site name", "url": "https://..."}
}]

Use ingredient names in "need" that closely match common pantry terms. The "need" list should only contain real ingredients used in the steps.`,
          },
        ],
        tools: [{ type: "web_search_20250305", name: "web_search" }],
      }),
    });

    const data = await anthropicResponse.json().catch(() => ({}));

    if (!anthropicResponse.ok) {
      return res.status(anthropicResponse.status).json({
        error: data?.error?.message || `Anthropic request failed (${anthropicResponse.status}).`,
      });
    }

    const text = (data.content || [])
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("\n");

    const recipes = normalizeRecipes(extractJsonArray(text));
    return res.status(200).json({ recipes });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Something went wrong searching recipes." });
  }
};
