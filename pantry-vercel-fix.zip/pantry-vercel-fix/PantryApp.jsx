import React, { useState, useMemo, useRef } from "react";
import { Plus, X, ChefHat, Search, Clock, Users, Flame, ChevronRight, Check, Camera, ArrowLeft, Loader2, AlertCircle } from "lucide-react";

/* ---------------------------------------------------------
   DATA
--------------------------------------------------------- */

const PANTRY_CATEGORIES = {
  Produce: ["Onion", "Garlic", "Tomato", "Bell Pepper", "Carrot", "Spinach", "Potato", "Lemon", "Lime", "Ginger", "Mushroom", "Zucchini", "Broccoli", "Avocado", "Cilantro", "Basil"],
  "Protein": ["Chicken Breast", "Eggs", "Ground Beef", "Tofu", "Salmon", "Shrimp", "Bacon", "Black Beans", "Chickpeas", "Lentils"],
  Dairy: ["Butter", "Milk", "Parmesan", "Mozzarella", "Greek Yogurt", "Cream Cheese", "Heavy Cream", "Cheddar"],
  Grains: ["Rice", "Pasta", "Bread", "Flour", "Tortillas", "Quinoa", "Oats"],
  Pantry: ["Olive Oil", "Soy Sauce", "Honey", "Canned Tomatoes", "Vegetable Broth", "Coconut Milk", "Peanut Butter", "Vinegar"],
  Spices: ["Salt", "Black Pepper", "Cumin", "Paprika", "Chili Flakes", "Oregano", "Cinnamon", "Curry Powder"],
};

const RECIPES = [
  {
    id: "r1",
    name: "Garlic Butter Skillet Chicken",
    blurb: "Pan-seared chicken finished in a nutty brown-butter garlic sauce.",
    time: 30, servings: 4, difficulty: "Easy", cuisine: "American",
    need: ["Chicken Breast", "Butter", "Garlic", "Lemon", "Salt", "Black Pepper"],
    have: [],
    steps: [
      { t: "Pound the chicken", d: "Place {Chicken Breast} between two sheets of plastic wrap and pound to an even ½-inch thickness. This helps it cook evenly and quickly.", time: 5 },
      { t: "Season", d: "Pat the chicken dry, then season both sides generously with {Salt} and {Black Pepper}.", time: 2 },
      { t: "Sear", d: "Heat 1 tbsp {Olive Oil} in a large skillet over medium-high heat. Sear chicken 5–6 minutes per side until golden and cooked through (165°F internal). Remove and rest on a plate.", time: 12 },
      { t: "Make the garlic butter", d: "Lower heat to medium. Add {Butter} and minced {Garlic} to the same skillet. Cook 60–90 seconds, swirling, until the butter smells nutty and the garlic is fragrant but not browned.", time: 3 },
      { t: "Finish", d: "Squeeze in juice from {Lemon}, scrape up any browned bits, then return chicken to the pan and spoon the sauce over top for 1 minute.", time: 2 },
      { t: "Rest & serve", d: "Let rest 3 minutes before slicing. Spoon extra sauce over each portion.", time: 3 },
    ],
    tips: "No meat mallet? A heavy pan or rolling pin works. Don't skip resting the chicken — it keeps the juices in.",
    swaps: "Chicken thighs work beautifully here too, and forgive overcooking more than breast meat.",
  },
  {
    id: "r2",
    name: "One-Pan Tomato Basil Pasta",
    blurb: "Everything — pasta included — cooks together in one pan for a silky, starchy sauce.",
    time: 25, servings: 4, difficulty: "Easy", cuisine: "Italian",
    need: ["Pasta", "Canned Tomatoes", "Garlic", "Onion", "Basil", "Olive Oil", "Parmesan", "Salt"],
    have: [],
    steps: [
      { t: "Build the base", d: "In a wide, deep skillet, combine dry {Pasta}, {Canned Tomatoes}, thinly sliced {Onion}, smashed {Garlic}, 3 tbsp {Olive Oil} and 1 tsp {Salt}.", time: 4 },
      { t: "Add water & cook", d: "Add 4 cups water — just enough to barely submerge the pasta. Bring to a boil, then reduce to a steady simmer.", time: 3 },
      { t: "Simmer, stirring often", d: "Cook 9–11 minutes, stirring frequently so the pasta doesn't stick, until the pasta is al dente and the liquid has reduced to a glossy sauce.", time: 11 },
      { t: "Finish", d: "Off heat, tear in fresh {Basil} and toss. Sauce should coat the pasta thickly — if it's loose, simmer 1–2 minutes more.", time: 2 },
      { t: "Serve", d: "Top with shaved {Parmesan} and a final drizzle of olive oil.", time: 1 },
    ],
    tips: "Stir more than you think you need to — this is what builds the creamy texture without any cream.",
    swaps: "No fresh basil? Stir in 1 tsp dried oregano with the base instead.",
  },
  {
    id: "r3",
    name: "Crispy Tofu & Broccoli Stir-Fry",
    blurb: "Cornstarch-crisped tofu with charred broccoli in a glossy soy-ginger sauce.",
    time: 35, servings: 3, difficulty: "Medium", cuisine: "Chinese-American",
    need: ["Tofu", "Broccoli", "Garlic", "Ginger", "Soy Sauce", "Rice", "Vegetable Broth"],
    have: [],
    steps: [
      { t: "Press the tofu", d: "Wrap {Tofu} in a clean towel, set something heavy on top, and let it press for 15 minutes to remove excess water — this is the secret to crisp tofu.", time: 15 },
      { t: "Cube & coat", d: "Cut tofu into 1-inch cubes and toss with 2 tbsp cornstarch until lightly coated.", time: 3 },
      { t: "Fry the tofu", d: "Heat oil in a wok or large skillet over medium-high. Fry tofu cubes 6–8 minutes, turning occasionally, until golden and crisp on most sides. Remove and set aside.", time: 8 },
      { t: "Cook the broccoli", d: "In the same pan, add {Broccoli} florets and stir-fry 3–4 minutes until bright green with some char.", time: 4 },
      { t: "Make the sauce", d: "Push broccoli aside, add minced {Garlic} and {Ginger}, cook 30 seconds, then stir in {Soy Sauce} and ¼ cup {Vegetable Broth}.", time: 2 },
      { t: "Combine & serve", d: "Return tofu to the pan, toss to coat in sauce until glossy, about 1 minute. Serve hot over steamed {Rice}.", time: 2 },
    ],
    tips: "Don't crowd the tofu in the pan — fry in batches if needed so each piece actually crisps instead of steaming.",
    swaps: "Swap broccoli for green beans or snap peas if that's what's on hand.",
  },
  {
    id: "r4",
    name: "Loaded Black Bean Tacos",
    blurb: "Smoky, spiced black beans piled into warm tortillas with quick toppings.",
    time: 20, servings: 4, difficulty: "Easy", cuisine: "Mexican",
    need: ["Black Beans", "Tortillas", "Onion", "Cumin", "Lime", "Cilantro", "Avocado"],
    have: [],
    steps: [
      { t: "Sauté aromatics", d: "Heat oil in a skillet over medium heat. Add diced {Onion} and cook 4 minutes until soft.", time: 4 },
      { t: "Spice & simmer", d: "Stir in {Cumin}, drained {Black Beans}, and a splash of water. Mash about a third of the beans with a fork for texture, then simmer 6–7 minutes.", time: 7 },
      { t: "Warm tortillas", d: "While beans simmer, warm {Tortillas} directly over a flame or in a dry skillet, 20 seconds per side.", time: 3 },
      { t: "Assemble", d: "Squeeze {Lime} juice into the beans, then pile onto tortillas with sliced {Avocado} and chopped {Cilantro}.", time: 3 },
    ],
    tips: "Mashing some of the beans (not all) gives you a sauce that holds the taco together.",
    swaps: "Pinto or kidney beans both work in place of black beans.",
  },
  {
    id: "r5",
    name: "Creamy Mushroom Risotto",
    blurb: "Slow-stirred rice in a rich parmesan-mushroom broth — restaurant-level comfort food.",
    time: 45, servings: 4, difficulty: "Hard", cuisine: "Italian",
    need: ["Rice", "Mushroom", "Onion", "Garlic", "Vegetable Broth", "Parmesan", "Butter"],
    have: [],
    steps: [
      { t: "Warm the broth", d: "In a separate pot, bring {Vegetable Broth} to a gentle simmer and keep it there — adding warm broth is key to a creamy texture.", time: 5 },
      { t: "Sauté mushrooms", d: "In a wide pan, melt half the {Butter} and cook sliced {Mushroom} until browned, about 6 minutes. Remove and set aside.", time: 6 },
      { t: "Build the base", d: "Add remaining butter, diced {Onion}, and minced {Garlic}. Cook 3 minutes until soft and fragrant.", time: 3 },
      { t: "Toast the rice", d: "Add {Rice} and stir for 1–2 minutes until edges turn translucent.", time: 2 },
      { t: "Add broth gradually", d: "Add warm broth one ladle at a time, stirring frequently and waiting until mostly absorbed before adding more. Repeat for 18–20 minutes.", time: 20 },
      { t: "Finish", d: "Stir in mushrooms and grated {Parmesan} off heat until creamy. Season to taste and serve immediately.", time: 3 },
    ],
    tips: "Resist walking away — risotto wants near-constant stirring and attention for that signature creaminess.",
    swaps: "Any broth works if vegetable isn't on hand; chicken broth adds extra richness.",
  },
  {
    id: "r6",
    name: "Shrimp & Avocado Rice Bowl",
    blurb: "Quick-seared lime shrimp over rice with cool avocado and a peanut drizzle.",
    time: 20, servings: 2, difficulty: "Easy", cuisine: "Fusion",
    need: ["Shrimp", "Rice", "Avocado", "Lime", "Garlic", "Peanut Butter", "Soy Sauce"],
    have: [],
    steps: [
      { t: "Cook rice", d: "If not already cooked, prepare {Rice} according to package instructions.", time: 15 },
      { t: "Make the sauce", d: "Whisk together 2 tbsp {Peanut Butter}, 1 tbsp {Soy Sauce}, juice of half a {Lime}, and 2 tbsp warm water until smooth.", time: 3 },
      { t: "Sear shrimp", d: "Heat oil in a skillet over medium-high. Add minced {Garlic} and {Shrimp}, cooking 1.5–2 minutes per side until pink and just opaque.", time: 4 },
      { t: "Assemble", d: "Spoon rice into bowls, top with shrimp and sliced {Avocado}, then drizzle generously with peanut sauce.", time: 2 },
    ],
    tips: "Shrimp cook fast — pull them the moment they turn pink to avoid rubberiness.",
    swaps: "Chicken or tofu both work in place of shrimp; adjust cook time accordingly.",
  },
  {
    id: "r7",
    name: "Spinach & Cheddar Baked Eggs",
    blurb: "A lazy-morning bake: eggs nestled into wilted spinach and melty cheddar.",
    time: 25, servings: 2, difficulty: "Easy", cuisine: "American",
    need: ["Eggs", "Spinach", "Cheddar", "Butter", "Garlic", "Salt"],
    have: [],
    steps: [
      { t: "Preheat & wilt spinach", d: "Preheat oven to 375°F. Melt {Butter} in an oven-safe skillet, add minced {Garlic} and {Spinach}, cooking until just wilted, 2 minutes.", time: 4 },
      { t: "Season", d: "Spread spinach evenly in the pan and season with {Salt}.", time: 1 },
      { t: "Add eggs", d: "Crack {Eggs} directly on top of the spinach, spacing them apart. Scatter shredded {Cheddar} over everything.", time: 3 },
      { t: "Bake", d: "Bake 10–12 minutes, until whites are set but yolks are still soft (longer if you prefer firm yolks).", time: 12 },
      { t: "Serve", d: "Let cool 2 minutes before serving straight from the pan with toast.", time: 2 },
    ],
    tips: "Use a skillet you don't mind going from stovetop to oven — cast iron is ideal here.",
    swaps: "Mozzarella or Swiss can stand in for cheddar.",
  },
  {
    id: "r8",
    name: "Curried Lentil Soup",
    blurb: "A warming, hands-off soup that gets better the longer it sits.",
    time: 40, servings: 6, difficulty: "Easy", cuisine: "Indian-inspired",
    need: ["Lentils", "Onion", "Carrot", "Garlic", "Curry Powder", "Coconut Milk", "Vegetable Broth"],
    have: [],
    steps: [
      { t: "Sauté vegetables", d: "Heat oil in a large pot. Add diced {Onion} and {Carrot}, cooking 5 minutes until softened.", time: 5 },
      { t: "Bloom the spices", d: "Add minced {Garlic} and 1.5 tbsp {Curry Powder}, stirring 1 minute until fragrant.", time: 1 },
      { t: "Add lentils & liquid", d: "Stir in rinsed {Lentils}, {Vegetable Broth}, and {Coconut Milk}. Bring to a boil.", time: 5 },
      { t: "Simmer", d: "Reduce heat and simmer uncovered 25–30 minutes, stirring occasionally, until lentils are tender and the soup has thickened.", time: 28 },
      { t: "Finish", d: "Season to taste with salt. Serve hot, with extra coconut milk swirled on top if desired.", time: 1 },
    ],
    tips: "Red lentils break down fastest if you want a smoother soup; green or brown hold their shape more.",
    swaps: "Any broth works; a splash of lemon at the end brightens it nicely.",
  },
];

/* ---------------------------------------------------------
   HELPERS
--------------------------------------------------------- */

const ALL_KNOWN_INGREDIENTS = Object.values(PANTRY_CATEGORIES).flat();

// Normalize for comparison: lowercase, trim, strip trailing "s" plurals, collapse whitespace.
function normalize(str) {
  return str
    .toLowerCase()
    .trim()
    .replace(/\s+/g, " ")
    .replace(/[.,]/g, "")
    .replace(/(es|s)$/, (m, p1, offset, full) => (full.length > 4 ? "" : m)); // crude de-pluralize, skip tiny words
}

// Try to map a freeform scanned name onto a known canonical ingredient name.
// Falls back to the original (title-cased) name if nothing matches closely.
function resolveToCanonical(rawName) {
  const norm = normalize(rawName);
  const exact = ALL_KNOWN_INGREDIENTS.find((k) => normalize(k) === norm);
  if (exact) return exact;
  // partial/contains match in either direction (e.g. "Roma Tomato" -> "Tomato")
  const partial = ALL_KNOWN_INGREDIENTS.find(
    (k) => norm.includes(normalize(k)) || normalize(k).includes(norm)
  );
  if (partial) return partial;
  return rawName.trim().replace(/\b\w/g, (c) => c.toUpperCase());
}


function matchScore(recipe, pantrySet) {
  const normalizedPantry = new Set(Array.from(pantrySet).map(normalize));
  const owns = (ingredient) => normalizedPantry.has(normalize(ingredient));
  const total = recipe.need.length;
  const have = recipe.need.filter(owns).length;
  return { have, total, missing: recipe.need.filter((i) => !owns(i)), pct: Math.round((have / total) * 100) };
}

// Shared lookup: does pantrySet contain something matching `name`, ignoring
// case/whitespace/simple plurals? Used anywhere we render an owned/missing state.
function pantryOwns(pantrySet, name) {
  const target = normalize(name);
  for (const item of pantrySet) {
    if (normalize(item) === target) return true;
  }
  return false;
}

function MatchMeter({ pct, size = 44 }) {
  const r = (size - 6) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  const color = pct === 100 ? "var(--sage)" : pct >= 60 ? "var(--walnut)" : "var(--paprika)";
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ flexShrink: 0 }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--parchment-dark)" strokeWidth="4" />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none"
        stroke={color} strokeWidth="4" strokeLinecap="round"
        strokeDasharray={c} strokeDashoffset={offset}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: "stroke-dashoffset 0.6s ease, stroke 0.3s ease" }}
      />
      <text x="50%" y="51%" textAnchor="middle" dominantBaseline="middle" fontFamily="'JetBrains Mono', monospace" fontSize={size * 0.3} fontWeight="600" fill="var(--ink)">
        {pct}
      </text>
    </svg>
  );
}

function highlightIngredients(text, pantrySet) {
  const parts = text.split(/(\{[^}]+\})/g);
  return parts.map((part, i) => {
    const m = part.match(/^\{([^}]+)\}$/);
    if (!m) return <span key={i}>{part}</span>;
    const name = m[1];
    const owned = pantryOwns(pantrySet, name);
    return (
      <span
        key={i}
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontWeight: 600,
          fontSize: "0.93em",
          padding: "0.1em 0.4em",
          borderRadius: "4px",
          background: owned ? "rgba(95,116,87,0.14)" : "rgba(199,93,61,0.12)",
          color: owned ? "var(--sage-dark)" : "var(--paprika)",
          whiteSpace: "nowrap",
        }}
      >
        {name}
      </span>
    );
  });
}

/* ---------------------------------------------------------
   MAIN APP
--------------------------------------------------------- */

export default function PantryApp() {
  const [pantry, setPantry] = useState(new Set(["Garlic", "Onion", "Olive Oil", "Salt", "Black Pepper", "Eggs", "Rice", "Butter"]));
  const [view, setView] = useState("pantry"); // pantry | recipes | detail
  const [activeRecipe, setActiveRecipe] = useState(null);
  const [search, setSearch] = useState("");
  const [customInput, setCustomInput] = useState("");
  const [activeCategory, setActiveCategory] = useState("Produce");
  const fileRef = useRef(null);

  // --- photo scan state ---
  const [scanStatus, setScanStatus] = useState("idle"); // idle | loading | review | error
  const [scanPreview, setScanPreview] = useState(null); // base64 image for preview
  const [scanResults, setScanResults] = useState([]); // [{name, confidence, category, checked}]
  const [scanError, setScanError] = useState("");

  // --- web recipe search state ---
  const [webRecipes, setWebRecipes] = useState([]); // recipes found via live web search
  const [webSearchStatus, setWebSearchStatus] = useState("idle"); // idle | loading | error
  const [webSearchError, setWebSearchError] = useState("");
  const [pantryAtLastSearch, setPantryAtLastSearch] = useState(null); // snapshot to detect staleness

  const pantryList = useMemo(() => Array.from(pantry), [pantry]);

  const toggleIngredient = (name) => {
    setPantry((prev) => {
      const next = new Set(prev);
      const existing = Array.from(next).find((item) => normalize(item) === normalize(name));
      if (existing) next.delete(existing);
      else next.add(name);
      return next;
    });
  };

  const addCustom = () => {
    const val = customInput.trim();
    if (!val) return;
    setPantry((prev) => new Set(prev).add(val.replace(/\b\w/g, (c) => c.toUpperCase())));
    setCustomInput("");
  };

  const compressImageForUpload = (file, maxDimension = 1600, quality = 0.82) =>
    new Promise((resolve, reject) => {
      if (!file.type?.startsWith("image/")) {
        reject(new Error("Please choose a photo file."));
        return;
      }

      const reader = new FileReader();
      reader.onerror = () => reject(new Error("Could not read file"));
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error("Could not load image"));
        img.onload = () => {
          const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
          const width = Math.max(1, Math.round(img.width * scale));
          const height = Math.max(1, Math.round(img.height * scale));
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext("2d");
          if (!ctx) {
            reject(new Error("Could not prepare image"));
            return;
          }

          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);

          const previewUrl = canvas.toDataURL("image/jpeg", quality);
          resolve({
            base64Data: previewUrl.split(",")[1],
            mediaType: "image/jpeg",
            previewUrl,
          });
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });

  const handlePhotoSelected = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = ""; // allow re-selecting the same file later

    setScanStatus("loading");
    setScanError("");

    try {
      const { base64Data, mediaType, previewUrl } = await compressImageForUpload(file);
      setScanPreview(previewUrl);

      const response = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ base64Data, mediaType }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `API error (${response.status})`);

      const parsed = data.items;
      if (!Array.isArray(parsed)) throw new Error("Unexpected response format");

      if (parsed.length === 0) {
        setScanError("No ingredients spotted in that photo. Try getting closer, or with better lighting.");
        setScanStatus("error");
        return;
      }

      setScanResults(
        parsed.map((item, i) => ({
          id: `${i}-${item.name || "ingredient"}`,
          name: item.name || "Unknown ingredient",
          category: item.category || "Other",
          confidence: typeof item.confidence === "number" ? item.confidence : 0.7,
          checked: true,
        }))
      );
      setScanStatus("review");
    } catch (err) {
      setScanError(err.message || "Something went wrong reading that photo.");
      setScanStatus("error");
    }
  };

  const toggleScanResult = (id) => {
    setScanResults((prev) => prev.map((r) => (r.id === id ? { ...r, checked: !r.checked } : r)));
  };

  const confirmScanResults = () => {
    setPantry((prev) => {
      const next = new Set(prev);
      scanResults
        .filter((r) => r.checked)
        .forEach((r) => {
          const canonical = resolveToCanonical(r.name);
          const alreadyHave = Array.from(next).some((item) => normalize(item) === normalize(canonical));
          if (!alreadyHave) next.add(canonical);
        });
      return next;
    });
    closeScan();
  };

  const closeScan = () => {
    setScanStatus("idle");
    setScanPreview(null);
    setScanResults([]);
    setScanError("");
  };

  const searchWebRecipes = async () => {
    if (pantryList.length === 0) {
      setWebSearchError("Add a few ingredients to your shelf first.");
      setWebSearchStatus("error");
      return;
    }
    setWebSearchStatus("loading");
    setWebSearchError("");

    try {
      const response = await fetch("/api/recipes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ingredients: pantryList }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Search failed (${response.status})`);

      const parsed = data.recipes;
      if (!Array.isArray(parsed) || parsed.length === 0) {
        throw new Error("No recipes came back — try adding more ingredients");
      }

      const normalized = parsed.map((r, i) => ({
        id: `web-${Date.now()}-${i}`,
        name: r.name || "Untitled recipe",
        blurb: r.blurb || "",
        time: r.time || 30,
        servings: r.servings || 4,
        difficulty: r.difficulty || "Medium",
        cuisine: r.cuisine || "",
        need: Array.isArray(r.need) ? r.need : [],
        steps: Array.isArray(r.steps) ? r.steps : [],
        tips: r.tips || "",
        swaps: r.swaps || "",
        source: r.source || null,
        isWebResult: true,
      }));

      setWebRecipes(normalized);
      setPantryAtLastSearch(new Set(pantry));
      setWebSearchStatus("idle");
    } catch (err) {
      setWebSearchError(err.message || "Something went wrong searching for recipes.");
      setWebSearchStatus("error");
    }
  };

  // True once the pantry has changed since the last successful web search, so we can
  // surface a gentle "your shelf changed" nudge rather than silently going stale.
  const webResultsAreStale = useMemo(() => {
    if (!pantryAtLastSearch) return false;
    if (pantryAtLastSearch.size !== pantry.size) return true;
    for (const item of pantry) if (!pantryAtLastSearch.has(item)) return true;
    return false;
  }, [pantry, pantryAtLastSearch]);

  const rankedRecipes = useMemo(() => {
    const combined = [...RECIPES, ...webRecipes];
    return combined
      .map((r) => ({ ...r, match: matchScore(r, pantry) }))
      .filter((r) => r.name.toLowerCase().includes(search.toLowerCase()) || (r.cuisine || "").toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => b.match.pct - a.match.pct || a.time - b.time);
  }, [pantry, search, webRecipes]);

  const filteredCategoryItems = PANTRY_CATEGORIES[activeCategory].filter((i) =>
    i.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ "--bg": "#FAF7F0", "--ink": "#2B2722", "--walnut": "#8C7158", "--walnut-dark": "#6B563F", "--sage": "#5F7457", "--sage-dark": "#465640", "--paprika": "#C75D3D", "--parchment": "#E8E1D3", "--parchment-dark": "#D9CFB9", fontFamily: "'Inter', sans-serif", background: "var(--bg)", color: "var(--ink)", minHeight: "100%", width: "100%" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap');
        * { box-sizing: border-box; }
        .pantry-app button { font-family: inherit; cursor: pointer; }
        .pantry-app ::-webkit-scrollbar { height: 6px; width: 6px; }
        .pantry-app ::-webkit-scrollbar-thumb { background: var(--parchment-dark); border-radius: 3px; }
        .chip { transition: all 0.15s ease; }
        .chip:active { transform: scale(0.96); }
        .recipe-card { transition: transform 0.18s ease, box-shadow 0.18s ease; }
        .recipe-card:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(43,39,34,0.1); }
        .nav-btn { transition: opacity 0.15s ease; }
        .nav-btn:hover { opacity: 0.7; }
        @keyframes flash { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .scanning { animation: flash 0.3s ease infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .spin { animation: spin 1s linear infinite; }
        @keyframes overlayIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes sheetUp { from { transform: translateY(24px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .scan-overlay { animation: overlayIn 0.2s ease; }
        .scan-sheet { animation: sheetUp 0.25s ease; }
        .step-num { font-family: 'Fraunces', serif; }
      `}</style>

      <div className="pantry-app" style={{ maxWidth: 720, margin: "0 auto", padding: "0 0 64px" }}>
        {/* HEADER */}
        <header style={{ padding: "28px 20px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--ink)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <ChefHat size={19} color="var(--bg)" strokeWidth={2} />
            </div>
            <span style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 22, letterSpacing: "-0.01em" }}>Shelf</span>
          </div>
          <nav style={{ display: "flex", gap: 18 }}>
            <button
              className="nav-btn"
              onClick={() => setView("pantry")}
              style={{ background: "none", border: "none", fontSize: 14, fontWeight: 600, color: view === "pantry" ? "var(--ink)" : "var(--walnut)", borderBottom: view === "pantry" ? "2px solid var(--ink)" : "2px solid transparent", paddingBottom: 4 }}
            >
              My Shelf
            </button>
            <button
              className="nav-btn"
              onClick={() => setView("recipes")}
              style={{ background: "none", border: "none", fontSize: 14, fontWeight: 600, color: view === "recipes" || view === "detail" ? "var(--ink)" : "var(--walnut)", borderBottom: view === "recipes" || view === "detail" ? "2px solid var(--ink)" : "2px solid transparent", paddingBottom: 4 }}
            >
              Recipes
            </button>
          </nav>
        </header>

        {/* ---------------- PANTRY VIEW ---------------- */}
        {view === "pantry" && (
          <div style={{ padding: "0 20px" }}>
            <h1 style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 30, lineHeight: 1.15, margin: "8px 0 6px", letterSpacing: "-0.01em" }}>
              What's in your kitchen?
            </h1>
            <p style={{ color: "var(--walnut-dark)", fontSize: 15, margin: "0 0 22px", lineHeight: 1.5 }}>
              Tap what you've got. We'll figure out what to cook with it.
            </p>

            {/* scan button */}
            <input ref={fileRef} type="file" accept="image/*" capture="environment" style={{ display: "none" }} onChange={handlePhotoSelected} />
            <button
              onClick={() => fileRef.current?.click()}
              disabled={scanStatus === "loading"}
              style={{
                width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 9,
                background: "var(--ink)", color: "var(--bg)", border: "none", borderRadius: 14,
                padding: "15px 18px", fontSize: 15, fontWeight: 600, marginBottom: 22,
                opacity: scanStatus === "loading" ? 0.75 : 1,
              }}
            >
              {scanStatus === "loading" ? (
                <>
                  <Loader2 size={18} className="spin" /> Reading your photo…
                </>
              ) : (
                <>
                  <Camera size={18} /> Scan a pantry photo
                </>
              )}
            </button>

            {/* selected pantry summary */}
            {pantryList.length > 0 && (
              <div style={{ marginBottom: 24 }}>
                <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--walnut)", marginBottom: 10 }}>
                  On your shelf · {pantryList.length}
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {pantryList.map((item) => (
                    <button
                      key={item}
                      className="chip"
                      onClick={() => toggleIngredient(item)}
                      style={{
                        display: "flex", alignItems: "center", gap: 6,
                        background: "var(--ink)", color: "var(--bg)", border: "none",
                        borderRadius: 20, padding: "7px 8px 7px 14px", fontSize: 13.5, fontWeight: 500,
                      }}
                    >
                      {item} <X size={13} strokeWidth={2.5} />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* custom add */}
            <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
              <input
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addCustom()}
                placeholder="Add something not listed below…"
                style={{
                  flex: 1, border: "1.5px solid var(--parchment-dark)", borderRadius: 12,
                  padding: "11px 14px", fontSize: 14, background: "var(--parchment)", color: "var(--ink)", outline: "none",
                }}
              />
              <button
                onClick={addCustom}
                style={{ background: "var(--parchment)", border: "1.5px solid var(--parchment-dark)", borderRadius: 12, width: 44, display: "flex", alignItems: "center", justifyContent: "center" }}
              >
                <Plus size={18} color="var(--ink)" />
              </button>
            </div>

            {/* category tabs */}
            <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 16, paddingBottom: 2 }}>
              {Object.keys(PANTRY_CATEGORIES).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  style={{
                    flexShrink: 0, border: "none", borderRadius: 18, padding: "8px 16px", fontSize: 13.5, fontWeight: 600,
                    background: activeCategory === cat ? "var(--sage)" : "var(--parchment)",
                    color: activeCategory === cat ? "var(--bg)" : "var(--walnut-dark)",
                  }}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* ingredient grid */}
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {filteredCategoryItems.map((item) => {
                const active = pantryOwns(pantry, item);
                return (
                  <button
                    key={item}
                    className="chip"
                    onClick={() => toggleIngredient(item)}
                    style={{
                      display: "flex", alignItems: "center", gap: 6,
                      border: active ? "1.5px solid var(--ink)" : "1.5px solid var(--parchment-dark)",
                      background: active ? "var(--ink)" : "transparent",
                      color: active ? "var(--bg)" : "var(--ink)",
                      borderRadius: 20, padding: "8px 14px", fontSize: 14, fontWeight: 500,
                    }}
                  >
                    {active && <Check size={13} strokeWidth={3} />}
                    {item}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setView("recipes")}
              style={{
                width: "100%", marginTop: 28, background: "var(--paprika)", color: "var(--bg)", border: "none",
                borderRadius: 14, padding: "16px 18px", fontSize: 15.5, fontWeight: 700,
                display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              }}
            >
              Find recipes I can make <ChevronRight size={18} />
            </button>
          </div>
        )}

        {/* ---------------- RECIPES LIST VIEW ---------------- */}
        {view === "recipes" && (
          <div style={{ padding: "0 20px" }}>
            <h1 style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 28, margin: "8px 0 4px", letterSpacing: "-0.01em" }}>
              Made for your shelf
            </h1>
            <p style={{ color: "var(--walnut-dark)", fontSize: 14.5, margin: "0 0 18px" }}>
              Ranked by how much you already have on hand.
            </p>

            <div style={{ position: "relative", marginBottom: 12 }}>
              <Search size={16} color="var(--walnut)" style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)" }} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search recipes or cuisine…"
                style={{
                  width: "100%", border: "1.5px solid var(--parchment-dark)", borderRadius: 12,
                  padding: "11px 14px 11px 38px", fontSize: 14, background: "var(--parchment)", color: "var(--ink)", outline: "none",
                }}
              />
            </div>

            <button
              onClick={searchWebRecipes}
              disabled={webSearchStatus === "loading"}
              style={{
                width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                background: webResultsAreStale ? "var(--paprika)" : "var(--sage)", color: "var(--bg)", border: "none",
                borderRadius: 12, padding: "13px 16px", fontSize: 14, fontWeight: 700, marginBottom: 18,
                opacity: webSearchStatus === "loading" ? 0.75 : 1,
              }}
            >
              {webSearchStatus === "loading" ? (
                <><Loader2 size={16} className="spin" /> Searching the web for recipes…</>
              ) : webRecipes.length > 0 ? (
                <><Search size={16} /> {webResultsAreStale ? "Shelf changed — refresh web recipes" : "Search the web again"}</>
              ) : (
                <><Search size={16} /> Find more recipes on the web</>
              )}
            </button>

            {webSearchStatus === "error" && (
              <div style={{ display: "flex", alignItems: "flex-start", gap: 10, background: "rgba(199,93,61,0.1)", borderRadius: 12, padding: 14, marginBottom: 18 }}>
                <AlertCircle size={16} color="var(--paprika)" style={{ flexShrink: 0, marginTop: 1 }} />
                <div style={{ fontSize: 13.5, color: "var(--ink)", lineHeight: 1.5 }}>{webSearchError}</div>
              </div>
            )}

            {webRecipes.length > 0 && webSearchStatus !== "loading" && (
              <div style={{ fontSize: 12.5, color: "var(--walnut)", marginBottom: 14, fontWeight: 600 }}>
                {webRecipes.length} recipe{webRecipes.length === 1 ? "" : "s"} found on the web
                {webResultsAreStale ? " · based on your shelf before your last change" : ""}
              </div>
            )}

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {rankedRecipes.map((r) => (
                <button
                  key={r.id}
                  className="recipe-card"
                  onClick={() => { setActiveRecipe(r); setView("detail"); }}
                  style={{
                    textAlign: "left", background: "var(--parchment)", border: "none", borderRadius: 16,
                    padding: 16, display: "flex", gap: 14, alignItems: "center", position: "relative",
                  }}
                >
                  <MatchMeter pct={r.match.pct} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 3 }}>
                      <div style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 17, color: "var(--ink)" }}>
                        {r.name}
                      </div>
                      {r.isWebResult && (
                        <span style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--sage-dark)", background: "rgba(95,116,87,0.14)", padding: "2px 7px", borderRadius: 8, flexShrink: 0 }}>
                          Web
                        </span>
                      )}
                    </div>
                    <div style={{ fontSize: 13, color: "var(--walnut-dark)", marginBottom: 7, lineHeight: 1.4 }}>
                      {r.blurb}
                    </div>
                    <div style={{ display: "flex", gap: 12, fontSize: 12.5, color: "var(--walnut)", fontWeight: 600 }}>
                      <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Clock size={12.5} /> {r.time} min</span>
                      <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Users size={12.5} /> {r.servings}</span>
                      <span>{r.difficulty}</span>
                    </div>
                    {r.match.missing.length > 0 && (
                      <div style={{ fontSize: 12, color: "var(--paprika)", marginTop: 7, fontWeight: 600 }}>
                        Missing: {r.match.missing.slice(0, 3).join(", ")}{r.match.missing.length > 3 ? ` +${r.match.missing.length - 3}` : ""}
                      </div>
                    )}
                  </div>
                  <ChevronRight size={18} color="var(--walnut)" style={{ flexShrink: 0 }} />
                </button>
              ))}
              {rankedRecipes.length === 0 && (
                <div style={{ textAlign: "center", padding: "40px 20px", color: "var(--walnut)" }}>
                  No recipes match that search.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ---------------- RECIPE DETAIL VIEW ---------------- */}
        {view === "detail" && activeRecipe && (
          <div>
            <div style={{ padding: "0 20px" }}>
              <button
                onClick={() => setView("recipes")}
                style={{ background: "none", border: "none", display: "flex", alignItems: "center", gap: 6, color: "var(--walnut-dark)", fontSize: 14, fontWeight: 600, padding: "4px 0 16px" }}
              >
                <ArrowLeft size={16} /> Back to recipes
              </button>

              <div style={{ display: "flex", alignItems: "flex-start", gap: 16, marginBottom: 6 }}>
                <h1 style={{ fontFamily: "'Fraunces', serif", fontWeight: 700, fontSize: 28, lineHeight: 1.15, margin: 0, flex: 1, letterSpacing: "-0.01em" }}>
                  {activeRecipe.name}
                </h1>
                <MatchMeter pct={activeRecipe.match.pct} size={52} />
              </div>
              <p style={{ color: "var(--walnut-dark)", fontSize: 15, lineHeight: 1.5, margin: "0 0 16px" }}>{activeRecipe.blurb}</p>

              <div style={{ display: "flex", gap: 16, marginBottom: 20, paddingBottom: 20, borderBottom: "1px solid var(--parchment-dark)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13.5, fontWeight: 600, color: "var(--ink)" }}>
                  <Clock size={15} color="var(--walnut)" /> {activeRecipe.time} min
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13.5, fontWeight: 600, color: "var(--ink)" }}>
                  <Users size={15} color="var(--walnut)" /> {activeRecipe.servings} servings
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13.5, fontWeight: 600, color: "var(--ink)" }}>
                  <Flame size={15} color="var(--walnut)" /> {activeRecipe.difficulty}
                </div>
              </div>

              {/* ingredients */}
              <div style={{ marginBottom: 26 }}>
                <div style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 17, marginBottom: 12 }}>Ingredients</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {activeRecipe.need.map((ing) => {
                    const owned = pantryOwns(pantry, ing);
                    return (
                      <div key={ing} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 14.5 }}>
                        <div style={{
                          width: 18, height: 18, borderRadius: 5, flexShrink: 0,
                          background: owned ? "var(--sage)" : "transparent",
                          border: owned ? "none" : "1.5px solid var(--parchment-dark)",
                          display: "flex", alignItems: "center", justifyContent: "center",
                        }}>
                          {owned && <Check size={12} color="var(--bg)" strokeWidth={3} />}
                        </div>
                        <span style={{ color: owned ? "var(--ink)" : "var(--walnut-dark)", textDecoration: owned ? "none" : "none" }}>
                          {ing}
                        </span>
                        {!owned && <span style={{ fontSize: 11.5, color: "var(--paprika)", fontWeight: 700, marginLeft: "auto", background: "rgba(199,93,61,0.1)", padding: "2px 8px", borderRadius: 10 }}>buy</span>}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* steps */}
              <div style={{ marginBottom: 26 }}>
                <div style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 17, marginBottom: 14 }}>Method</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                  {activeRecipe.steps.map((step, i) => (
                    <div key={i} style={{ display: "flex", gap: 14 }}>
                      <div className="step-num" style={{
                        width: 30, height: 30, borderRadius: "50%", flexShrink: 0,
                        background: "var(--parchment)", border: "1.5px solid var(--parchment-dark)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontWeight: 600, fontSize: 14, color: "var(--walnut-dark)",
                      }}>
                        {i + 1}
                      </div>
                      <div style={{ flex: 1, paddingTop: 2 }}>
                        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 4 }}>
                          <span style={{ fontWeight: 700, fontSize: 14.5 }}>{step.t}</span>
                          {step.time && (
                            <span style={{ fontSize: 12, color: "var(--walnut)", fontFamily: "'JetBrains Mono', monospace", fontWeight: 600, flexShrink: 0, marginLeft: 8 }}>
                              {step.time} min
                            </span>
                          )}
                        </div>
                        <div style={{ fontSize: 14, lineHeight: 1.6, color: "var(--ink)" }}>
                          {highlightIngredients(step.d, pantry)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* tips & swaps */}
              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 30 }}>
                <div style={{ background: "var(--parchment)", borderRadius: 12, padding: 14 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--sage-dark)", marginBottom: 5 }}>
                    Cook's tip
                  </div>
                  <div style={{ fontSize: 13.5, lineHeight: 1.5, color: "var(--ink)" }}>{activeRecipe.tips}</div>
                </div>
                <div style={{ background: "var(--parchment)", borderRadius: 12, padding: 14 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--walnut-dark)", marginBottom: 5 }}>
                    Swaps
                  </div>
                  <div style={{ fontSize: 13.5, lineHeight: 1.5, color: "var(--ink)" }}>{activeRecipe.swaps}</div>
                </div>
                {activeRecipe.isWebResult && activeRecipe.source?.url && (
                  <a
                    href={activeRecipe.source.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: "flex", alignItems: "center", justifyContent: "space-between",
                      background: "var(--parchment)", borderRadius: 12, padding: 14,
                      textDecoration: "none", color: "var(--ink)",
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--walnut)", marginBottom: 4 }}>
                        Original recipe
                      </div>
                      <div style={{ fontSize: 13.5, fontWeight: 600 }}>{activeRecipe.source.name || "View source"}</div>
                    </div>
                    <ChevronRight size={16} color="var(--walnut)" />
                  </a>
                )}
              </div>
            </div>
          </div>
        )}
        {/* ---------------- SCAN REVIEW / ERROR OVERLAY ---------------- */}
        {(scanStatus === "review" || scanStatus === "error") && (
          <div
            className="scan-overlay"
            style={{
              position: "fixed", inset: 0, background: "rgba(43,39,34,0.55)",
              display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 50,
            }}
            onClick={closeScan}
          >
            <div
              className="scan-sheet"
              onClick={(e) => e.stopPropagation()}
              style={{
                background: "var(--bg)", borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 720,
                maxHeight: "85vh", overflowY: "auto", padding: "20px 20px 28px",
              }}
            >
              <div style={{ width: 40, height: 4, background: "var(--parchment-dark)", borderRadius: 2, margin: "0 auto 18px" }} />

              {scanStatus === "error" && (
                <div style={{ textAlign: "center", padding: "20px 12px" }}>
                  <div style={{ width: 52, height: 52, borderRadius: "50%", background: "rgba(199,93,61,0.12)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
                    <AlertCircle size={24} color="var(--paprika)" />
                  </div>
                  <div style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 19, marginBottom: 8 }}>
                    Couldn't read that photo
                  </div>
                  <p style={{ fontSize: 14, color: "var(--walnut-dark)", lineHeight: 1.5, marginBottom: 22 }}>{scanError}</p>
                  <button
                    onClick={closeScan}
                    style={{ background: "var(--ink)", color: "var(--bg)", border: "none", borderRadius: 12, padding: "12px 28px", fontSize: 14.5, fontWeight: 600 }}
                  >
                    Try again
                  </button>
                </div>
              )}

              {scanStatus === "review" && (
                <>
                  <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 18 }}>
                    {scanPreview && (
                      <img src={scanPreview} alt="Scanned pantry" style={{ width: 56, height: 56, borderRadius: 12, objectFit: "cover", flexShrink: 0 }} />
                    )}
                    <div>
                      <div style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, fontSize: 19 }}>
                        Found {scanResults.length} item{scanResults.length === 1 ? "" : "s"}
                      </div>
                      <div style={{ fontSize: 13, color: "var(--walnut-dark)" }}>Uncheck anything that's wrong, then confirm.</div>
                    </div>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 22 }}>
                    {scanResults.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => toggleScanResult(item.id)}
                        style={{
                          display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left",
                          background: item.checked ? "var(--parchment)" : "transparent",
                          border: item.checked ? "1.5px solid var(--parchment)" : "1.5px solid var(--parchment-dark)",
                          borderRadius: 12, padding: "12px 14px",
                        }}
                      >
                        <div style={{
                          width: 20, height: 20, borderRadius: 6, flexShrink: 0,
                          background: item.checked ? "var(--sage)" : "transparent",
                          border: item.checked ? "none" : "1.5px solid var(--parchment-dark)",
                          display: "flex", alignItems: "center", justifyContent: "center",
                        }}>
                          {item.checked && <Check size={13} color="var(--bg)" strokeWidth={3} />}
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 14.5, fontWeight: 600, color: item.checked ? "var(--ink)" : "var(--walnut)" }}>{item.name}</div>
                          <div style={{ fontSize: 12, color: "var(--walnut)" }}>{item.category}</div>
                        </div>
                        {item.confidence < 0.6 && (
                          <span style={{ fontSize: 11, fontWeight: 700, color: "var(--paprika)", background: "rgba(199,93,61,0.1)", padding: "3px 8px", borderRadius: 8, flexShrink: 0 }}>
                            not sure
                          </span>
                        )}
                      </button>
                    ))}
                  </div>

                  <div style={{ display: "flex", gap: 10 }}>
                    <button
                      onClick={closeScan}
                      style={{ flex: 1, background: "transparent", border: "1.5px solid var(--parchment-dark)", borderRadius: 12, padding: "13px", fontSize: 14.5, fontWeight: 600, color: "var(--ink)" }}
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmScanResults}
                      disabled={!scanResults.some((r) => r.checked)}
                      style={{
                        flex: 2, background: "var(--ink)", color: "var(--bg)", border: "none", borderRadius: 12,
                        padding: "13px", fontSize: 14.5, fontWeight: 700,
                        opacity: scanResults.some((r) => r.checked) ? 1 : 0.5,
                      }}
                    >
                      Add {scanResults.filter((r) => r.checked).length} to shelf
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
